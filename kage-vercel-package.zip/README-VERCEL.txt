# Vercel static deployment package

The `dist/` directory is configured as the static output directory for Vercel.

## Important: runtime assets are missing from the files uploaded in chat

The supplied `index.html` references files that were not included in the upload:
- `secret-pathways-assets/three.min.js`
- `secret-pathways-assets/fonts.css`
- `secret-pathways-assets/generated/*.webp`
- `secret-pathways-assets/foreground/png/*.webp`

Because those files are missing, the site may deploy but its Three.js scene, fonts, and imagery will not work correctly until the complete `secret-pathways-assets/` folder is added. Upload that folder at the repository root (alongside `index.html`) and copy it into `dist/secret-pathways-assets/` for this static-output setup, or instead deploy the complete project root with Vercel's output directory set to `.`.

## Vercel settings
- Framework Preset: Other
- Build Command: leave empty
- Output Directory: `dist`

This is a static HTML project; the uploaded `package.json` has no build script, so `npm run build` will fail.
